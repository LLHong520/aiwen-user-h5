<template>
<layout>
  <!--  -->
   <m-header slot="page_header"  title='支付'>
     <span class="retrun" slot='left' @click="backToLastPage">
       <b class="gray"></b>
      </span>
      <span class="placeholder" slot='right'>
        <span class="mr10">&nbsp;&nbsp;&nbsp;&nbsp;</span>
      </span>
   </m-header>
  <!--  -->
  <!-- page_container -->
  <div slot="page_container" class="app_wrapper_inner">
    <section class="wrapper payment">
      <h1 class="pay-title">请选择支付方式</h1>
      <ul class="payment-types">
        <template v-for="(payment,index) in paymentList">
          <li :class="{'active':payment.choose}" v-if="payment.isSupport" :key="index" @click="callPay(payment.en)">
            <a :class="{'choose':payment.choose}" href="javascript:;">
              <img v-if="payment.en == 'wbpay'" height="18" src="./images/weibo.png" />
              <img v-if="payment.en == 'wechatpay'" height="18" src="./images/weixin.png" />
              <img v-if="payment.en == 'alipay'" height="20" src="./images/alipay.png" />
            {{payment.name}}</a>
          </li>
        </template>
      </ul>
      <!-- 去支付按钮 -->
      <div class="btn_fixed">
        <a
          href="javascript:;"
          class="btn_blue"
          @click="doPay"
        >去支付</a>
      </div>
    </section>

  </div>
    <!-- 去支付按钮 -->
    <!-- /page_container -->

    <!-- page_footer -->
    <div slot="page_footer" class="app_wrapper_inner">
      <!-- 支付中提示 -->
      <div v-show="loadingPayPage" class="loading_page">
        <div class="loading">
        <img width="24" height="24" src="./images/loading.gif">
          <p class="desc">初始化支付中...</p>
        </div>
      </div>
      <!-- 支付中提示 -->
      <!-- 支付中提示 -->
      <div v-show="payOrdering" class="loading_page">
        <div class="loading">
        <img width="24" height="24" src="./images/loading.gif">
          <p class="desc">支付中...</p>
        </div>
      </div>
      <!-- 支付中提示 -->
      <!-- 未完成订单提示 -->
      <div slot="page_layer">
        <div class="shadow" v-if="showPayFailTip"></div>
        <div class="layer_confirm" v-if="showPayFailTip">
          <div class="layer_cont">支付失败，请稍后重试</div>
          <div class="layer_btn">
            <a href="javascript:;" class="btn_ok" @click="closeLayer">好的</a>
          </div>
        </div>
      </div>
    <!-- 未完成订单提示 -->
    </div>
</layout>
</template>
<script>
  import { commonMixin,shareMixin } from "@/mixins";
  import paymentService from "@/services/paymentService.js";
  import Header from "@/components/header/Header";
  export default {
    mixins:[commonMixin,shareMixin],
    components: {
      mHeader:Header,
    },
    data() {
      return {
        showPayFailTip:false,
        paymentList: {
          wbpay:{
            name: "微博支付",
            en: "wbpay",
            isSupport: false,
            choose: false,
          },
          alipay:{
            name: "支付宝支付",
            en: "alipay",
            isSupport: false,
            choose: false,
          },
          wechatpay:{
            name: "微信支付",
            en: "wechatpay",
            isSupport: false,
            choose: false,
          },
        },
        businessId: "",
        doctorId: "",
        payOrdering: false,
        loadingPayPage: true,
      };
    },
    computed: {
      isSupportWbPay(){
        let is = false;
        let matchInfo = navigator.userAgent.match(/__weibo__([\d\.]+)/i);
        if (matchInfo) {
          let version = parseFloat(matchInfo[1]);
          if (version >= 4.3) {
            is = true;
          }
        }
        return is;
      },
      isSupportWXPay(){
        let is = false;
        let matchInfo = navigator.userAgent.match(/MicroMessenger\/([\d\.]+)/i);
        if (matchInfo) {
          let version = parseFloat(matchInfo[1]);
          if (version >= 5.0) {
            is = true;
          }
        }
        return is;
      },
      typeName(){
        let typeName = "";
        for (const key in this.paymentList) {
          if(this.paymentList[key].choose){
            typeName = this.paymentList[key].en;
          }
        }
        return typeName;
      }
    },
    created() {
      // "5ca5c79b563bd80007a0382f"
      this.businessId = this.$route.params.businessId;
      this.doctorId = this.$route.query.dId;
      this.initPayList();
      if (platformInfo.isWx) {
        //微信免签名支付
        this.payWithoutConfig();
        // this.getWXconfig();
      }else if(platformInfo.isWeibo){
        console.log("wx");
        this.callWBpay();
      }
      console.log(this.isSupportWbPay);
      console.log(this.paymentList);

      // let supportList = this.paymentList.filter((item)=>{
      //   return item.isSupport == true;
      // });
      // let supportLength = supportList.length;
      // if(supportLength == 1){
      //   this.callPay(supportList[0].en);
      // }
    },
    mounted(){
      this.loadingPayPage = false;
    },
    methods: {
      closeLayer(){
        this.backToLastPage();
      },
      doPay(){
        let typeName = this.typeName;
        console.log(typeName);
        if (typeName === "alipay") {
          this.callAliPay();
        } else if (typeName === "wechatpay") {
          this.payWithoutConfig();
        } else {
          this.callWBpay();
        }
      },
      initPayList(){
        if(this.isSupportWbPay){
          this.paymentList["wbpay"].isSupport = true;
          this.paymentList["wbpay"].choose = true;
        }
        if(this.isSupportWXPay){
          this.paymentList["wechatpay"].isSupport = true;
          this.paymentList["wechatpay"].choose = true;
        }
        if(!platformInfo.isWx){
          this.paymentList["alipay"].isSupport = true;
        }
        if(!platformInfo.isWx&&!this.isSupportWbPay){
          this.paymentList["alipay"].choose = true;
        }

      },
      /*
      * 调起支付
      */
      callPay(typeName) {
        for (const key in this.paymentList) {
          this.paymentList[key].choose = false;
        }
        this.paymentList[typeName].choose = true;
      },
      /*
      * 发起支付宝支付
      */
      callAliPay() {
        if(this.payOrdering) return;
        this.payOrdering = true;
        console.log("调起支付宝支付");
        paymentService.payOrder({
          payType: "alipayM",
          businessType: "dr_telePhone",
          businessId: this.businessId,
        })
          .then(res => {
            this.payOrdering = false;
            console.log(res);
            console.log(res.data);
            if (res.code == 0 && res.data) {
              if(res.data.status && res.data.status == "PAY_SUCCESS"){
                this.$toast.tip("订单已支付~");
                this.backToLastPage();
              }else{
                window.location.href = res.data.payUrl;
              }
            } else {
              this.payCallback(false);
            }
          })
          .catch(()=>{
            this.payCallback(false);
            this.payOrdering = false;
          });
      },
      /*
      * 发起微信支付
      */
      callWechatpay() {
        if(this.payOrdering) return;
        this.payOrdering = true;
        console.log("调起微信支付");
        paymentService.payOrder({
          payType: "weixinPay",
          businessType: "dr_telePhone",
          businessId: this.businessId,
        })
          .then(res => {
            this.payOrdering = false;
            console.log(res);
            console.log(res.data);
            if (res.code == 0 && res.data) {
              this.chooseWxToPay(res.data);
            } else {
              this.payCallback(false);
            }
          })
          .catch(()=>{
            this.payCallback(false);
            this.payOrdering = false;
          });
      },
      /*
      * 发起微博支付
      */
      callWBpay() {
        // if(!this.isSupportWbPay) return;
        if(this.payOrdering) return;
        this.payOrdering = true;
        console.log("调起微博支付");
        paymentService.payOrder({
          payType: "weiboPay",
          businessType: "dr_telePhone",
          businessId: this.businessId,
        })
          .then(res => {
            this.payOrdering = false;
            console.log(res);
            console.log(res.data);
            if (res.code == 0 && res.data) {
              if(res.data.status && res.data.status == "PAY_SUCCESS"){
                this.payCallback(true);
              }else{
                window.location.href = res.data.payUrl;
              }
            } else {
              this.payCallback(false);
            }
          })
          .catch(()=>{
            this.payCallback(false);
            this.payOrdering = false;
          });
      },
      /*
      * 支付成功或者失败回调
      */
      payCallback(isSucc) {
        if(isSucc){
          this.$toast.tip("支付成功");
        }else{
          this.showPayFailTip = true;
        }
      },
      /*
      * 微信免签名支付
      */
      payWithoutConfig(){
        if(this.payOrdering) return;
        this.payOrdering = true;
        paymentService.payOrder({
          payType: "weixinPay",
          businessType: "dr_telePhone",
          businessId: this.businessId,
        })
          .then(res => {
            this.payOrdering = false;
            console.log(res);
            console.log(res.data);
            if (res.code == 0 && res.data) {
              if(res.data.status && res.data.status == "PAY_SUCCESS"){
                this.$toast.tip("订单已支付~");
                this.backToLastPage();
              }else{
                this.weixinJSBridgePay(res.data);
              }
            } else {
              this.payCallback(false);
            }
          });
      },
      weixinJSBridgePay(data){
        // let _this = this;
        let conf = data.reqParamWeixin;
        function onBridgeReady(){
          WeixinJSBridge.invoke(
            "getBrandWCPayRequest", {
              "appId":conf.appId,//公众号名称，由商户传入
              "timeStamp":conf.timeStamp,//时间戳，自1970年以来的秒数
              "nonceStr":conf.nonceStr,//随机串
              "package":conf.packageInfo,
              "signType":conf.signType,//微信签名方式：
              "paySign":conf.paySign//微信签名
            },
            function(res){
              // _this.$toast.tip(res.err_msg);
              if(res.err_msg == "get_brand_wcpay_request:ok" ){
                // 使用以上方式判断前端返回,微信团队郑重提示：
                //res.err_msg将在用户支付成功后返回ok，但并不保证它绝对可靠。
                // _this.payCallback(true);
                // alert(`/awyh/pay/weixinPayMReturn?orderId=${data.orderId}`);
                window.location.href = `/awyh/pay/weixinPayMReturn?orderId=${data.orderId}`;
              }else if(res.err_msg == "get_brand_wcpay_request:fail"){
			    	    // _this.payCallback(false);
			        }
            });
        }
        if (typeof WeixinJSBridge == "undefined"){
          if( document.addEventListener ){
            document.addEventListener("WeixinJSBridgeReady", onBridgeReady, false);
          }else if (document.attachEvent){
            document.attachEvent("WeixinJSBridgeReady", onBridgeReady);
            document.attachEvent("onWeixinJSBridgeReady", onBridgeReady);
          }
        }else{
          onBridgeReady();
        }
      },
      /*
      * 微信支付前签名
      */
      getWXconfig(){
        if(!this.isSupportWXPay) return;
        let params = {
          url: window.location.href.split("#")[0]
        };
        paymentService.getWXconfig(params)
          .then(res => {
            console.log(res);
            console.log(res.data);
            if (res.code == 0 && res.data) {
              this.configWx(res.data);
            } else {
              this.$toast.tip("支付失败，请稍后重试");
            }
          });
      },
      /*
      * 设置签名
      */
      configWx(conf){
        let _this = this;
        wx.config({
          appId: conf.appId,
          timestamp: conf.timestamp,
          nonceStr: conf.nonceStr,
          signature: conf.signature,
          jsApiList: [ "chooseWXPay" ],
          success: function (res) {
            //alert("wx.config OK:" + JSON.stringify(res));
            _this.callWechatpay();
          },
          fail: function (res) {
            //无法配置当前页面, 不能发起支付, 请在此转异常处理流程[2]
            //alert("wx.config error:" + JSON.stringify(res));
            _this.payCallback(false);
          }
        });
      },
      /*
      * 发起微信支付
      */
      chooseWxToPay(msg){
        let _this = this;
        wx.chooseWXPay({
          timestamp: msg.timeStamp,
          nonceStr: msg.nonceStr,
          package: msg.package,
          signType: msg.signType,
          paySign: msg.paySign,
          success: function (res) {
              //完成微信支付, 跳转到成功页面, 同时传入所需的订单信息
            var okUrl = "";
            window.location.href = okUrl;
          },
          fail: function (res) {
            //支付失败, 请在此转异常处理流程[5]
            //alert("wx.chooseWXPay\r\n" + JSON.stringify(res));
            _this.payCallback(false);
          }
        });
      },
      backToLastPage(isDelay){
        if(isDelay){
          setTimeout(() => {
            this.$router.replace({
              name:"dialogueList",
              params:{
                dId:this.doctorId
              },
              query:{
                backto:"docRome"
              }
            });
          }, 2000);
        }else{
          this.$router.replace({
            name:"dialogueList",
            params:{
              dId:this.doctorId
            },
            query:{
              backto:"docRome"
            }
          });
        }
      }
    }
  };

</script>

<style lang="less" scoped>
  @assets: "~@/assets";
  @import "@{assets}/css/flex.less";
  @import "@{assets}/css/fix.less";
    .shadow{
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    background-color: rgba(0,0,0,.3);
    z-index: 995;
  }
  .layer_confirm{
    position: fixed;
    width: 500/@r;
    background-color: #fff;
    border-radius: 20/@r;
    left: 50%;
    top: 50%;
    margin-left: -250/@r;
    margin-top: -117/@r;
    z-index: 996;
    .layer_cont{
      font-size: 30/@r;
      line-height: 44/@r;
      color: #000;
      padding: 34/@r 38/@r 28/@r 38/@r;
      text-align: center;
    }
    .layer_btn{
      display: flex;
      border-top: 1px solid #E7E7E7;
      a{
        display: block;
        flex: 1;
        height: 82/@r;
        line-height: 82/@r;
        font-size: 30/@r;
        color: #007AFF;
        text-align: center;
      }
    }
  }
  .payment-types {
    font-size: 14px;
    li {
      padding: 0px 30px;
      border-bottom: 1px solid #f8f8f8;
      img{
        vertical-align: middle;
        margin-right:10px;
      }
    }
    a{
      padding: 20px 0px;
      display:block;
    }
    a.choose{
      color:#2688FC;
      display:block;
      background:url(./images/choose.png) no-repeat right;
      background-size:20px;
    }
  }

  .pay-title{
    background-color:#f2f2f2;
    color:#333;
    padding:15px;
  }


  .btn_fixed{
    padding: 15px;
    background-color: #fff;
    // position: fixed;
    left: 0;
    right: 0;
    bottom: 15px;
    height: 40px;
    padding-bottom: env(safe-area-inset-bottom);
    .btn_blue{
      display: inline-block;
      width: 100%;
      height: 40px;
      color: #fff;
      background-color: #2688FC;
      font-size: 15px;
      line-height: 40px;
      text-align: center;
      &.disabled{
        background-color: rgba(38, 136, 252, 0.4);
      }
    }
  }


  .loading_page{
    position: fixed;
    top: 0;
    left: 0;
    right:0;
    bottom: 0;
    z-index: 9999;
    background-color: rgba(0, 0, 0, 0);
  }
  .loading{
    width: 100px;
    margin: 0 auto;
    position: fixed;
    left: 50%;
    top: 50%;
    margin-left: -50px;
    margin-top: -50px;
    text-align: center;
    padding: 0px 0px;
    background-color: rgba(0, 0, 0, .6);
    border-radius:10px;
    padding-top: 30px;
    box-sizeing:border-box;
    img{
      // width:60/@r;
    }
    .desc{
      line-height: 20px;
      font-size:14px;
      color:#ccc;
      padding: 15px 0;
    }
  }
</style>
